# Paper Trading System Microsite

This repository contains the single-page frontend for `paper-trading.shazilfarukh.com`. It presents Muhammad Shazil Farukh’s multi-strategy Alpaca paper-trading system as a **research-to-production operating system**, with architecture, strategy lifecycle, capital constraints, attribution, positions, and sleeve contribution shown without performance theatre.

## Project Overview

| Area | Implementation |
|---|---|
| Framework | React 19, TypeScript, Vite |
| Motion | Framer Motion with `prefers-reduced-motion` support |
| Styling | Tailwind 4 foundation plus a bespoke CSS design system |
| Data | Replaceable static contract at `client/public/data/portfolio.json` |
| Primary interaction | Scroll-synced architecture story with sticky detail card and active system spine |
| Fonts | Calibre and SF Mono stacks, currently using the approved Inter and Fira Code fallbacks |

## Local Development

Install dependencies and start the Vite development server:

```bash
pnpm install
pnpm dev
```

Run the validation commands before publishing:

```bash
pnpm check
pnpm build
```

The production frontend is emitted to `dist/public`.

## Content and Data Updates

All replaceable portfolio evidence lives in `client/public/data/portfolio.json`. The page fetches this file at runtime, so positions, budgets, strategies, and sleeve contribution can be updated without redesigning the components.

| JSON field | Purpose |
|---|---|
| `as_of` | EOD snapshot date shown in the book section |
| `budgets` | Lifetime caps used by the utilization instruments |
| `strategies` | Lifecycle, thesis, rules, notes, code, and notebook links |
| `positions` | Strategy ownership, symbols, quantities, notional, and notes |
| `sleeve_realized_pnl` | Approximate algorithmic sleeve contribution values |

Discretionary rows must retain `"discretionary": true`. The UI deliberately de-emphasizes those rows and excludes them from sleeve contribution.

## Architecture Scroll Experience

On desktop, the architecture detail card is sticky while four tall timeline stages pass the viewport. An `IntersectionObserver` selects the stage closest to the reading band, while Framer Motion maps scroll progress to the illuminated spine and traveling packet. Clicking a stage scrolls it to the active reading position.

On screens below `901px`, the narrative becomes a selectable horizontal step rail above a stacked detail card. When the visitor requests reduced motion, automatic scroll synchronization and sticky pinning are disabled; every stage remains directly selectable.

## Brand and Font Notes

The CSS variables in `client/src/index.css` reproduce the supplied portfolio palette, type scale, radius, and motion tokens. Mint `#64ffda` is intentionally reserved for live system state, links, focus, and positive contribution. Negative contribution uses the restrained semantic red `#e06c75`.

Calibre and SF Mono binaries were not included with the source attachments. The implementation therefore follows the approved fallback order: Inter for sans text and Fira Code for mono text. If licensed Calibre and SF Mono files become available, host them through the project’s managed static storage or another licensed CDN, add `@font-face` declarations, and keep the existing family names at the front of each stack.

## Hosting and the Target Subdomain

### Manus Hosting

Manus includes hosting and custom-domain support for this project. After a checkpoint is created, use the **Publish** control in the project UI, then open **Settings → Domains** to bind `paper-trading.shazilfarukh.com`. This is the most direct path because the generated visual assets already use project-managed `/manus-storage/` URLs.

### Vercel Alternative

If the repository is exported to Vercel, configure these values:

| Setting | Value |
|---|---|
| Install command | `pnpm install` |
| Build command | `pnpm build` |
| Output directory | `dist/public` |
| Node runtime | Node 22 or a compatible supported release |

Add `paper-trading.shazilfarukh.com` in the Vercel domain settings and create the DNS record Vercel requests. External hosting may require compatibility changes: the current generated images are served from project-managed `/manus-storage/` URLs and should be re-hosted on the external deployment before cutover.

## Important Files

| Path | Responsibility |
|---|---|
| `client/src/components/ArchitectureScroll.tsx` | Scroll-synced system story |
| `client/src/components/Strategies.tsx` | Lifecycle filters and strategy evidence |
| `client/src/components/Book.tsx` | Budget instruments and strategy-owned positions |
| `client/src/components/Contribution.tsx` | Muted realized-contribution bars |
| `client/src/index.css` | Complete visual system and responsive behavior |
| `client/public/data/portfolio.json` | Replaceable data contract |
| `DESIGN_DECISIONS.md` | Concise interaction and brand rationale |
| `ideas.md` | Full design direction and review amendments |

## Content Caveat

The displayed account is an **Alpaca paper account**. The supplied snapshot and contribution values are illustrative, the live sample is short, and research metrics are not live performance. The site is not investment advice.
