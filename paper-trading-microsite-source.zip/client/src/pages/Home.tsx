/** Calm Technical Instrument: a single editorial systems narrative, powered by a replaceable static JSON contract. */
import { useEffect, useState } from "react";
import ArchitectureScroll from "@/components/ArchitectureScroll";
import Book from "@/components/Book";
import Contribution from "@/components/Contribution";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import Nav from "@/components/Nav";
import Strategies from "@/components/Strategies";
import type { PortfolioData } from "@/types/portfolio";

export default function Home() {
  const [data, setData] = useState<PortfolioData | null>(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    fetch("/data/portfolio.json", { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Portfolio data failed to load");
        return response.json() as Promise<PortfolioData>;
      })
      .then(setData)
      .catch((reason: unknown) => {
        if (reason instanceof DOMException && reason.name === "AbortError") return;
        setError(true);
      });
    return () => controller.abort();
  }, []);

  if (error) {
    return (
      <main className="data-state">
        <span>DATA CONTRACT / OFFLINE</span>
        <h1>The portfolio snapshot could not be loaded.</h1>
        <p>Refresh the page or confirm that <code>/data/portfolio.json</code> is available.</p>
      </main>
    );
  }

  if (!data) {
    return (
      <main className="data-state" aria-live="polite">
        <span>BOOTING PAPER BOOK</span>
        <div className="data-loader"><i /><i /><i /><i /></div>
      </main>
    );
  }

  return (
    <div id="top" className="site-shell">
      <Nav repo={data.repo} portfolioHome={data.portfolio_home} />
      <main>
        <Hero repo={data.repo} />
        <ArchitectureScroll />
        <Strategies strategies={data.strategies} />
        <Book positions={data.positions} budgets={data.budgets} asOf={data.as_of} disclaimer={data.disclaimer} />
        <Contribution pnl={data.sleeve_realized_pnl} />
      </main>
      <Footer repo={data.repo} portfolioHome={data.portfolio_home} />
    </div>
  );
}
