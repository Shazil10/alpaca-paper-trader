/**
 * Calm Technical Instrument: typed, explicit data structures reinforce the site's
 * research-to-production credibility and keep the UI ready for a public JSON feed.
 */
export type StrategyStatus = "Running" | "Research" | "Retired";

export interface StrategyLink {
  label: "Code" | "Notebook";
  url: string;
}

export interface Strategy {
  id: string;
  name: string;
  status: StrategyStatus;
  budget: number | null;
  module?: string;
  thesis: string;
  rules: string[];
  note: string;
  links: StrategyLink[];
}

export interface Position {
  strategy: string;
  symbol: string;
  qty: number;
  notional: number;
  notional_display: string;
  note: string;
  discretionary?: boolean;
}

export interface SleevePnl {
  label: string;
  pnl: number;
}

export interface PortfolioData {
  as_of: string;
  disclaimer: string;
  repo: string;
  portfolio_home: string;
  budgets: Record<string, number>;
  strategies: Strategy[];
  positions: Position[];
  sleeve_realized_pnl: SleevePnl[];
}
