/** Calm Technical Instrument: strategy cards expose lifecycle, rules, budgets, and source links without performance hype. */
import { useMemo, useState } from "react";
import { BookOpen, ChevronDown, Code2, ExternalLink } from "lucide-react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import type { Strategy, StrategyStatus } from "@/types/portfolio";
import SectionHeader from "./SectionHeader";

const STRATEGIES_ART_URL = "/manus-storage/strategy-sleeves-field_24a66a58.png";
const filters: Array<"All" | StrategyStatus> = ["All", "Running", "Research", "Retired"];

function StrategyCard({ strategy, ordinal }: { strategy: Strategy; ordinal: number }) {
  const [expanded, setExpanded] = useState(false);
  const reduceMotion = useReducedMotion();
  const visibleRules = expanded ? strategy.rules : strategy.rules.slice(0, 3);

  return (
    <motion.article
      className={`strategy-card strategy-card--${strategy.status.toLowerCase()}`}
      data-status={strategy.status}
      layout={!reduceMotion}
      initial={reduceMotion ? false : { opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={reduceMotion ? undefined : { opacity: 0, y: -8 }}
      transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
    >
      <div className="strategy-topline">
        <div className="strategy-identity">
          <span className="strategy-ordinal">S-{String(ordinal + 1).padStart(2, "0")}</span>
          <span className={`status-tag status-tag--${strategy.status.toLowerCase()}`}>
            <i aria-hidden="true" /> {strategy.status}
          </span>
        </div>
        <span className="budget-label">
          {strategy.budget ? `$${strategy.budget.toLocaleString()} lifetime` : "No live budget"}
        </span>
      </div>

      <div className="strategy-heading">
        <h3>{strategy.name}</h3>
        {strategy.module && <code>{strategy.module}</code>}
      </div>

      <p className="strategy-thesis">{strategy.thesis}</p>

      <div className="rules-block">
        <p className="micro-label">RULE SET</p>
        <ul>
          {visibleRules.map((rule) => <li key={rule}>{rule}</li>)}
        </ul>
        {strategy.rules.length > 3 && (
          <button className="expand-rules" type="button" onClick={() => setExpanded((value) => !value)}>
            {expanded ? "Collapse rules" : `Show ${strategy.rules.length - 3} more`}
            <ChevronDown className={expanded ? "is-rotated" : ""} size={15} aria-hidden="true" />
          </button>
        )}
      </div>

      <p className="strategy-note"><span>NOTE</span>{strategy.note}</p>

      <div className="strategy-links">
        {strategy.links.map((link) => (
          <a href={link.url} target="_blank" rel="noreferrer" key={`${strategy.id}-${link.label}`}>
            {link.label === "Code" ? <Code2 size={15} /> : <BookOpen size={15} />}
            {link.label}
            <ExternalLink size={12} aria-hidden="true" />
          </a>
        ))}
      </div>
    </motion.article>
  );
}

export default function Strategies({ strategies }: { strategies: Strategy[] }) {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const filtered = useMemo(
    () => (filter === "All" ? strategies : strategies.filter((strategy) => strategy.status === filter)),
    [filter, strategies],
  );
  const runningCount = strategies.filter((strategy) => strategy.status === "Running").length;
  const researchCount = strategies.filter((strategy) => strategy.status === "Research").length;

  return (
    <section id="strategies" className="section strategies-section">
      <img className="strategies-art" src={STRATEGIES_ART_URL} alt="" aria-hidden="true" />
      <div className="section-inner">
        <SectionHeader
          label="02. Strategies"
          title="Running, research, retired"
          lede="Live sleeves are capital-constrained and monitored. Research sleeves stay in notebooks until they clear ops and validation constraints."
        />

        <div className="lifecycle-board" aria-label="Strategy lifecycle summary">
          <div className="lifecycle-contract">
            <span className="micro-label">SHARED PRODUCTION CONTRACT</span>
            <code>generate_signals(budget, strategy_id, held_symbols)</code>
          </div>
          <div className="lifecycle-stats">
            <span><strong>{String(runningCount).padStart(2, "0")}</strong><small>RUNNING</small></span>
            <i aria-hidden="true" />
            <span><strong>{String(researchCount).padStart(2, "0")}</strong><small>RESEARCH</small></span>
            <i aria-hidden="true" />
            <span><strong>$40K</strong><small>LIFETIME CAPS</small></span>
          </div>
        </div>

        <div className="filter-rail" role="tablist" aria-label="Filter strategies by lifecycle status">
          {filters.map((item) => {
            const count = item === "All" ? strategies.length : strategies.filter((strategy) => strategy.status === item).length;
            return (
              <button
                key={item}
                type="button"
                role="tab"
                aria-selected={filter === item}
                className={filter === item ? "is-active" : ""}
                onClick={() => setFilter(item)}
              >
                {item}<span>{String(count).padStart(2, "0")}</span>
              </button>
            );
          })}
        </div>

        <motion.div className="strategy-grid" layout>
          <AnimatePresence mode="popLayout">
            {filtered.map((strategy, index) => (
              <StrategyCard strategy={strategy} ordinal={index} key={strategy.id} />
            ))}
          </AnimatePresence>
          {filtered.length === 0 && (
            <motion.div className="empty-strategies" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <span>RETIREMENT LOG / EMPTY</span>
              <h3>No retired sleeves.</h3>
              <p>The lifecycle filter is ready when a production strategy is formally decommissioned.</p>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
