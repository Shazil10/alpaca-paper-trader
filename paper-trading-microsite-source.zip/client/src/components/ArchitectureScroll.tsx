/** Calm Technical Instrument: architecture is a four-beat operating story with one precise active signal. */
import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { BookOpenCheck, Boxes, GitBranch, Workflow } from "lucide-react";
import SectionHeader from "./SectionHeader";

const ARCHITECTURE_ART_URL = "/manus-storage/architecture-flow-panel_ee3f7447.png";

export interface ArchitectureBeat {
  badge: string;
  kicker: string;
  headline: string;
  body: string;
  chipTitle: string;
  chipSub: string;
  bullets: string[];
  Icon: typeof BookOpenCheck;
}

const beats: ArchitectureBeat[] = [
  {
    badge: "01 / RESEARCH",
    kicker: "Notebooks first",
    headline: "Ideas earn a budget first.",
    body: "Hypotheses are tested in notebooks. Only rules that survive research get a live adapter and dollars — live metrics stay separate from backtest Sharpes.",
    chipTitle: "Notebooks first",
    chipSub: "parameters · walk-forward",
    bullets: [
      "Parameter sets locked from studies (e.g. R2 v2)",
      "Research sleeves stay capital-free until ready",
      "No confusing paper PnL with research Sharpe",
    ],
    Icon: BookOpenCheck,
  },
  {
    badge: "02 / STRATEGIES",
    kicker: "Shared interface",
    headline: "One contract, three engines.",
    body: "Every live sleeve exposes generate_signals(budget, strategy_id, held_symbols). Inside: momentum, regime rotation, or pullback mean reversion.",
    chipTitle: "Shared interface",
    chipSub: "momentum · rotation · MR",
    bullets: [
      "Clenow: cross-sectional trend + inverse-vol sizing",
      "Ranked: monthly V4/V8 blend + optional DAF leverage",
      "Pullback MR: deep 52-week drawdowns with quality gates",
    ],
    Icon: Boxes,
  },
  {
    badge: "03 / ORCHESTRATOR",
    kicker: "Capital ownership",
    headline: "Capital and ownership, not just signals.",
    body: "trade.py turns intents into safe broker actions — lifetime caps, attribution, sell-before-buy, and a cash reserve.",
    chipTitle: "trade.py",
    chipSub: "budgets · attribution",
    bullets: [
      "Lifetime budget caps; sells recycle capacity",
      "Fills tagged strategies.*:uuid",
      "Per-strategy holdings from history ∩ positions",
      "SELL first, refresh, then BUY · 10% cash reserve",
    ],
    Icon: GitBranch,
  },
  {
    badge: "04 / OPS",
    kicker: "Scheduled operations",
    headline: "Unattended runs with an audit trail.",
    body: "Weekday GitHub Actions: universe → trade → report. DST-aware gates, daily artifacts, and a manual liquidation path when orders stick.",
    chipTitle: "GitHub Actions",
    chipSub: "cron · reports · liquidate",
    bullets: [
      "Dual cron + ET time gate",
      "CSV / MD / HTML order tape with FIFO PnL",
      "Emergency close workflow for paper positions",
    ],
    Icon: Workflow,
  },
];

export default function ArchitectureScroll() {
  const [active, setActive] = useState(0);
  const [isDesktop, setIsDesktop] = useState(false);
  const reduceMotion = useReducedMotion();
  const timelineRef = useRef<HTMLDivElement>(null);
  const stepRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const { scrollYProgress } = useScroll({
    target: timelineRef,
    offset: ["start center", "end center"],
  });
  const packetTop = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);
  const beat = beats[active];
  const Icon = beat.Icon;

  useEffect(() => {
    const media = window.matchMedia("(min-width: 901px)");
    const updateViewport = () => setIsDesktop(media.matches);
    updateViewport();
    media.addEventListener("change", updateViewport);
    return () => media.removeEventListener("change", updateViewport);
  }, []);

  useEffect(() => {
    if (!isDesktop || reduceMotion) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (!visible) return;
        const index = Number((visible.target as HTMLElement).dataset.step);
        if (Number.isFinite(index)) setActive(index);
      },
      { rootMargin: "-41% 0px -41% 0px", threshold: [0, 0.01, 0.2] },
    );

    stepRefs.current.forEach((step) => step && observer.observe(step));
    return () => observer.disconnect();
  }, [isDesktop, reduceMotion]);

  const selectStep = (index: number) => {
    setActive(index);
    if (isDesktop && !reduceMotion) {
      stepRefs.current[index]?.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  };

  return (
    <section id="architecture" className="section architecture-section">
      <div className="architecture-orbit" aria-hidden="true" />
      <div className="section-inner">
        <SectionHeader
          label="01. Architecture"
          title="Research to a scheduled book"
          lede="Scroll through the loop. A sticky story card tracks the active stage while the spine lights up — research, strategies, orchestration, ops."
        />

        <div className="architecture-grid">
          <div className="architecture-sticky">
            <div className="architecture-card">
              <img className="architecture-art" src={ARCHITECTURE_ART_URL} alt="" aria-hidden="true" />
              <div className="card-grid-texture" aria-hidden="true" />
              <div className="architecture-card-topline">
                <span>{beat.badge}</span>
                <span className="live-state"><i /> STAGE ACTIVE</span>
              </div>

              <motion.div
                className="architecture-card-content"
                key={beat.badge}
                initial={reduceMotion ? false : { opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
              >
                <div className="architecture-icon"><Icon size={22} strokeWidth={1.6} /></div>
                <p className="micro-label">{beat.kicker}</p>
                <h3>{beat.headline}</h3>
                <p className="architecture-body">{beat.body}</p>

                <div className="architecture-chip">
                  <span>{beat.chipTitle}</span>
                  <code>{beat.chipSub}</code>
                </div>

                <ul className="architecture-bullets">
                  {beat.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}
                </ul>
              </motion.div>

              <div className="architecture-card-footer">
                <span>PIPELINE / PAPER</span>
                <span>{String(active + 1).padStart(2, "0")} — {String(beats.length).padStart(2, "0")}</span>
              </div>
            </div>
          </div>

          <div
            ref={timelineRef}
            className="architecture-timeline"
            style={{ "--active-step": active } as React.CSSProperties}
          >
            <div className="timeline-track" aria-hidden="true">
              <motion.span
                className="timeline-fill"
                style={isDesktop
                  ? { scaleY: reduceMotion ? active / 3 : scrollYProgress }
                  : { scaleX: active / 3 }}
              />
              <motion.span
                className="timeline-packet"
                style={isDesktop
                  ? { top: reduceMotion ? `${(active / 3) * 100}%` : packetTop, left: "50%" }
                  : { top: "50%", left: `${(active / 3) * 100}%` }}
              />
            </div>
            {beats.map((item, index) => {
              const TimelineIcon = item.Icon;
              return (
                <button
                  ref={(node) => { stepRefs.current[index] = node; }}
                  data-step={index}
                  className={`timeline-step ${index === active ? "is-active" : ""} ${index < active ? "is-complete" : ""}`}
                  key={item.badge}
                  type="button"
                  onClick={() => selectStep(index)}
                  aria-current={index === active ? "step" : undefined}
                >
                  <span className="timeline-node"><TimelineIcon size={17} strokeWidth={1.7} /></span>
                  <span className="timeline-copy">
                    <small>{item.badge}</small>
                    <strong>{item.headline}</strong>
                    <em>{item.chipSub}</em>
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="system-truth" aria-label="System architecture summary">
          <span>UNIVERSE REFRESH<small>S&amp;P 500/400/600 · liquidity</small></span>
          <i aria-hidden="true" />
          <span>STRATEGY SLEEVES<small>Clenow / Ranked / MR</small></span>
          <i aria-hidden="true" />
          <span>ORCHESTRATOR<small>SELL first · budgets · tags</small></span>
          <i aria-hidden="true" />
          <span>BROKER / REPORT<small>Alpaca paper · artifacts</small></span>
        </div>
      </div>
    </section>
  );
}

export { beats };
