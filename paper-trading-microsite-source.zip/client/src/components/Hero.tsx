/** Calm Technical Instrument: hero leads with process, leaving performance theatre outside the frame. */
import { ArrowDownRight, Github } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";

const HERO_URL = "/manus-storage/paper-trading-hero-system_c1c793fa.png";
const chips = ["Python", "Alpaca paper", "GitHub Actions", "Lifetime budgets", "Order attribution"];

interface HeroProps {
  repo: string;
}

export default function Hero({ repo }: HeroProps) {
  const reduceMotion = useReducedMotion();
  const initial = reduceMotion ? false : { opacity: 0, y: 18 };

  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="hero-noise" aria-hidden="true" />
      <div className="hero-inner">
        <motion.div
          className="hero-copy"
          initial={initial}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, ease: [0.23, 1, 0.32, 1] }}
        >
          <p className="eyebrow">Alpaca paper · research → production</p>
          <h1 id="hero-title">
            Multi-strategy
            <span>paper trading system</span>
          </h1>
          <p className="hero-body">
            Strategies own selection and sizing. A single orchestrator enforces capital caps,
            attribution, and execution safety. The whole loop runs unattended on GitHub Actions —
            built to show process, not a flashy equity curve.
          </p>

          <ul className="hero-chips" aria-label="Technology and system characteristics">
            {chips.map((chip) => (
              <li key={chip}>{chip}</li>
            ))}
          </ul>

          <div className="hero-actions">
            <a className="outline-button primary-cta" href="#architecture">
              See the system
              <ArrowDownRight size={16} aria-hidden="true" />
            </a>
            <a className="text-link" href={repo} target="_blank" rel="noreferrer">
              <Github size={16} aria-hidden="true" />
              View code
            </a>
          </div>
        </motion.div>

        <motion.aside
          className="hero-visual"
          aria-label="Abstract research-to-production system flow"
          initial={reduceMotion ? false : { opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.12, ease: [0.23, 1, 0.32, 1] }}
        >
          <div className="visual-corner visual-corner--top" aria-hidden="true" />
          <img src={HERO_URL} alt="Abstract four-stage paper trading system flow" />
          <div className="hero-instrument">
            <div>
              <span className="instrument-kicker">scheduled.paper_book</span>
              <strong>Four stages · one audit trail</strong>
            </div>
            <span className="status-light"><i /> PAPER / ACTIVE</span>
          </div>
          <div className="system-route" aria-hidden="true">
            <span>UNIVERSE</span><i />
            <span>SLEEVES</span><i />
            <span>ORCHESTRATOR</span><i />
            <span>REPORT</span>
          </div>
        </motion.aside>
      </div>
      <a className="scroll-cue" href="#architecture" aria-label="Scroll to architecture">
        <span>Scroll to inspect</span>
        <i aria-hidden="true" />
      </a>
    </section>
  );
}
