/** Calm Technical Instrument: sleeve contribution uses accurate, muted bars rather than a promotional equity curve. */
import type { SleevePnl } from "@/types/portfolio";
import SectionHeader from "./SectionHeader";

export default function Contribution({ pnl }: { pnl: SleevePnl[] }) {
  const maxAbs = Math.max(...pnl.map((item) => Math.abs(item.pnl)), 1);

  return (
    <section id="contribution" className="section contribution-section">
      <div className="section-inner contribution-layout">
        <div>
          <SectionHeader
            label="04. Sleeve contribution"
            title="Where live PnL came from"
            lede="Muted view of realized contribution by algorithmic sleeve. Short paper sample — process evidence, not a performance pitch."
          />
          <div className="contribution-note">
            <span>ATTRIBUTION SCOPE</span>
            <p>Only algorithmic sleeves are shown. Manual positions are excluded from strategy alpha by design.</p>
          </div>
        </div>

        <figure className="contribution-chart">
          <figcaption>Paper account · discretionary excluded · approximate</figcaption>
          <div className="chart-axis"><span>$0</span></div>
          <div className="chart-rows">
            {pnl.map((item) => {
              const width = (Math.abs(item.pnl) / maxAbs) * 92;
              const negative = item.pnl < 0;
              return (
                <div className="chart-row" key={item.label}>
                  <span className="chart-label">{item.label}</span>
                  <div className="chart-plot">
                    <i className="zero-line" aria-hidden="true" />
                    <span
                      className={`pnl-bar ${negative ? "is-negative" : "is-positive"}`}
                      style={{
                        width: `${Math.max(width, 0.8)}%`,
                        left: negative ? `${8 - Math.max(width, 0.8)}%` : "8%",
                      }}
                    />
                    <strong className={negative ? "is-negative" : ""}>
                      {negative ? "−" : "+"}${Math.abs(item.pnl).toLocaleString()}
                    </strong>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="chart-footer">
            <span><i className="mint-key" /> Realized contribution</span>
            <span><i className="red-key" /> Negative</span>
            <code>ILLUSTRATIVE / SHORT SAMPLE</code>
          </div>
        </figure>
      </div>
    </section>
  );
}
