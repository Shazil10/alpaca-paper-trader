/** Calm Technical Instrument: navigation is sparse, indexed, and anchored by a custom circuit mark. */
import { useEffect, useState } from "react";
import { Github, Menu, X } from "lucide-react";

const LOGO_URL = "/manus-storage/sf-circuit-mark_15c3f893.png";

const links = [
  { label: "01. Architecture", href: "#architecture" },
  { label: "02. Strategies", href: "#strategies" },
  { label: "03. Book", href: "#book" },
  { label: "04. Contribution", href: "#contribution" },
];

interface NavProps {
  repo: string;
  portfolioHome: string;
}

export default function Nav({ repo, portfolioHome }: NavProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 32);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  return (
    <header className={`site-nav ${scrolled ? "is-scrolled" : ""}`}>
      <a className="brand-lockup" href={portfolioHome} aria-label="Return to shazilfarukh.com">
        <span className="brand-mark"><img src={LOGO_URL} alt="SF circuit mark" /></span>
        <span className="brand-signature">
          <strong>SHAZIL / SYSTEMS</strong>
          <small>paper.book_v1</small>
        </span>
      </a>

      <nav className="desktop-nav" aria-label="Primary navigation">
        <ol>
          {links.map((link) => (
            <li key={link.href}><a href={link.href}>{link.label}</a></li>
          ))}
        </ol>
        <a className="outline-button nav-cta" href={repo} target="_blank" rel="noreferrer">
          <Github size={15} aria-hidden="true" /> GitHub
        </a>
      </nav>

      <button
        className="menu-trigger"
        type="button"
        aria-label={open ? "Close navigation" : "Open navigation"}
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        {open ? <X size={23} /> : <Menu size={23} />}
      </button>

      <div className={`mobile-nav ${open ? "is-open" : ""}`} aria-hidden={!open}>
        <nav aria-label="Mobile navigation">
          <ol>
            {links.map((link) => (
              <li key={link.href}>
                <a href={link.href} onClick={() => setOpen(false)}>
                  <span>{link.label.slice(0, 3)}</span>{link.label.slice(4)}
                </a>
              </li>
            ))}
          </ol>
          <a className="outline-button" href={repo} target="_blank" rel="noreferrer">
            <Github size={15} aria-hidden="true" /> GitHub
          </a>
        </nav>
      </div>
    </header>
  );
}
