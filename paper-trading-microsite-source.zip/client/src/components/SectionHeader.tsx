/** Calm Technical Instrument: editorial headings use indexed mono labels and restrained hierarchy. */
import { motion, useReducedMotion } from "framer-motion";

interface SectionHeaderProps {
  label: string;
  title: string;
  lede: string;
  className?: string;
}

export default function SectionHeader({ label, title, lede, className = "" }: SectionHeaderProps) {
  const reduceMotion = useReducedMotion();
  const sectionIndex = label.slice(0, 2);

  return (
    <motion.header
      className={`section-header ${className}`}
      data-section-index={sectionIndex}
      initial={reduceMotion ? false : { opacity: 0, y: 16 }}
      whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.45 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
    >
      <span className="section-index" aria-hidden="true">{sectionIndex}</span>
      <p className="section-label">{label}</p>
      <h2>{title}</h2>
      <p className="section-lede">{lede}</p>
    </motion.header>
  );
}
