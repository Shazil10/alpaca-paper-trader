/** Calm Technical Instrument: the book is presented as a concrete, caveated operating artifact. */
import { AlertTriangle } from "lucide-react";
import type { Position } from "@/types/portfolio";
import SectionHeader from "./SectionHeader";

interface BookProps {
  positions: Position[];
  budgets: Record<string, number>;
  asOf: string;
  disclaimer: string;
}

export default function Book({ positions, budgets, asOf, disclaimer }: BookProps) {
  const deployed = Object.fromEntries(
    Object.keys(budgets).map((strategy) => [
      strategy,
      positions.filter((position) => position.strategy === strategy).reduce((total, position) => total + position.notional, 0),
    ]),
  );

  return (
    <section id="book" className="section book-section">
      <div className="section-inner">
        <SectionHeader
          label="03. Book snapshot"
          title="Positions by strategy"
          lede="A concrete EOD artifact grouped by owning sleeve, with discretionary positions deliberately separated from algorithmic attribution."
        />

        <div className="book-meta">
          <p>As of {asOf} (EOD snapshot · illustrative)</p>
          <span><AlertTriangle size={15} aria-hidden="true" /> {disclaimer}</span>
        </div>

        <div className="budget-panel">
          <div className="budget-panel-heading">
            <div>
              <span className="micro-label">LIFETIME ALLOCATION CONTROL</span>
              <h3>Deployed vs. cap</h3>
            </div>
            <code>SELL PROCEEDS RECYCLE CAPACITY</code>
          </div>
          <div className="budget-grid">
            {Object.entries(budgets).map(([strategy, budget]) => {
              const used = deployed[strategy] ?? 0;
              const utilization = Math.min((used / budget) * 100, 100);
              return (
                <div className="budget-item" key={strategy}>
                  <div><span>{strategy}</span><strong>${used.toLocaleString()} <small>/ ${budget.toLocaleString()}</small></strong></div>
                  <div className="budget-track"><i style={{ width: `${utilization}%` }} /></div>
                  <code>{utilization.toFixed(0)}% deployed</code>
                </div>
              );
            })}
          </div>
        </div>

        <div className="book-table-wrap">
          <table className="book-table">
            <thead><tr><th>Strategy</th><th>Symbol</th><th>Qty</th><th>Notional</th><th>Notes</th></tr></thead>
            <tbody>
              {positions.map((position, index) => (
                <tr className={position.discretionary ? "is-discretionary" : ""} key={`${position.strategy}-${position.symbol}`}>
                  <td data-label="Strategy">
                    {index === 0 || positions[index - 1].strategy !== position.strategy ? position.strategy : <span className="continued">↳</span>}
                    {position.discretionary && <small>MANUAL / EXCLUDED</small>}
                  </td>
                  <td data-label="Symbol"><strong>{position.symbol}</strong></td>
                  <td data-label="Qty">{position.qty}</td>
                  <td data-label="Notional">{position.notional_display}</td>
                  <td data-label="Notes">{position.note || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
