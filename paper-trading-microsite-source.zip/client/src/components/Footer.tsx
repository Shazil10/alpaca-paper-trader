/** Calm Technical Instrument: the footer closes with explicit paper status and direct source links. */
import { ArrowUpRight, Github } from "lucide-react";

interface FooterProps {
  repo: string;
  portfolioHome: string;
}

export default function Footer({ repo, portfolioHome }: FooterProps) {
  return (
    <footer className="site-footer">
      <div className="footer-route" aria-hidden="true"><i /><span>RESEARCH</span><i /><span>PRODUCTION</span><i /></div>
      <div className="footer-inner">
        <div>
          <p className="eyebrow">System notes / end of line</p>
          <h2>Built for quant interviews.<br /><span>Paper trading only.</span></h2>
        </div>
        <div className="footer-links">
          <a href={portfolioHome}>
            shazilfarukh.com <ArrowUpRight size={15} aria-hidden="true" />
          </a>
          <a href={repo} target="_blank" rel="noreferrer">
            <Github size={15} aria-hidden="true" /> alpaca-paper-trader
          </a>
        </div>
      </div>
      <div className="footer-bottom">
        <span>MUHAMMAD SHAZIL FARUKH</span>
        <a href="#top">BACK TO TOP ↑</a>
      </div>
    </footer>
  );
}
