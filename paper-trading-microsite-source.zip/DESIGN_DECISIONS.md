# Design Decisions

The site uses the supplied navy-and-mint portfolio system as a technical instrument rather than a generic fintech dashboard. Dark navy provides continuity with `shazilfarukh.com`; near-white slate establishes editorial hierarchy; mint is scarce and appears primarily as a live signal, focus state, or system connection.

The architecture chapter is the signature interaction. Four viewport-height stages drive a sticky detail card, continuous spine, active node, and traveling packet. This makes the research → strategies → orchestrator → ops loop legible as an operating system. On mobile and under reduced-motion preferences, the same content becomes directly selectable without scroll scrubbing.

Strategy evidence is arranged as an asymmetric lifecycle board rather than an even card grid. Status, module path, shared interface, lifetime budget, rules, and source links carry more visual weight than result language. The book and contribution sections retain the same corner-cut glass, internal grid, and hairline materials while keeping all quantitative values deterministic HTML and CSS.

The generated abstract imagery is deliberately subordinate to the content. It supports the hero and architecture atmosphere without depicting equity curves, candlesticks, retail-trading clichés, or uncaveated performance claims.
